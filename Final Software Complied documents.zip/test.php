<?php include('config.php') ?>

<?php
$sql = "SELECT course FROM course_enrollment";
$result = $db->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "course: " . $row["course"].  "<br>";
  }
} else {
  echo "0 results";
}
$db->close();
?>